export class Customer {
    email:string;
    custFirstName:string;
    custLastName:string;
    password:string;
}
