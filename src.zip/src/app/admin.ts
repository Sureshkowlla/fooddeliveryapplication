export class Admin {
    foodId:number;
    foodName:string;
    foodDesc:string;
    foodPrice:number;
    foodType:string;
    foodImage:string;

}
